package com.customException;

public class Exception_Create extends RuntimeException {
public Exception_Create(String msg)
{
	super(msg);
}
}
