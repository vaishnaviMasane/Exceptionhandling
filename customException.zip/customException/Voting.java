package com.customException;

public class Voting {
public static void main(String[] args) {
	int age=16;
	if(age<18)
	{ try {
		throw new Exception_Create("You are not eligible for voting");
	}catch(Exception_Create e)
	{
		System.out.println(e.getMessage());
	}
	}
	else
	{
		System.out.println("voting Sucessfully!!");
	}

}
}
