package com.arithmaticException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileNotFound1 {

	public static void main(String[] args) {
  try { FileInputStream fis=new FileInputStream("D:\\Cdac\\JAVA\\SelfAssignment\\Practice\\Demo\\src");
	}
  catch(FileNotFoundException e) //also we can use FileNotFoundException
  {
	  System.out.println(e);
  }
 System.out.println("Non Discrupt Normal Flow of program!!");
	}

}
