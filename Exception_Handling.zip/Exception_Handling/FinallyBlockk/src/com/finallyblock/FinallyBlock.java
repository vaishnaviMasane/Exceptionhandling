package com.finallyblock;

public class FinallyBlock {

	public static void main(String[] args) {
try
{
	int a=100;
	int b=0;
	int c;
	c=100/0;
	System.out.println(c);
}
catch(Exception e)
{
	e.printStackTrace();
	//System.out.println(e);
	//System.out.println(e.getMessage());
}
finally
{
	System.out.println("I am in finally block");
}
	}

}
