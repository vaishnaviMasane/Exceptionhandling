package demo;

public class Demo {

	public static void main(String[] args) {

		System.out.println("1");
		System.out.println("10");
		System.out.println("20");
		//System.out.println(30/0); Arithmatic Exception
		System.out.println("40");
		System.out.println("50");
	}

}
